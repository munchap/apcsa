
/**
 * This class performs some basic word processing functions, 
 * namely find, remove, and replace.
 *
 * @author  (your name)
 * @version (today's date)
 */
public class WordProcessor
{

}
